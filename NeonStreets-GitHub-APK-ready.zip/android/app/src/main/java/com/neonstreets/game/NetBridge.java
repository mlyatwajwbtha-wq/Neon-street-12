package com.neonstreets.game;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * جسر شبكي محلي بسيط للعب التنائي عبر نقطة اتصال (هوت سبوت) بين جهازين، بدون إنترنت.
 * جهاز "المُضيف" يفتح ServerSocket وينتظر اتصال صديقه على نفس شبكة الواي فاي/الهوت سبوت.
 * جهاز "المنضم" يتصل مباشرة بعنوان IP الخاص بالمضيف.
 * البروتوكول: أسطر نصية JSON مفصولة بسطر جديد (\n) في الاتجاهين — بسيط ومضمون بيننا نحن فقط
 * (لسنا بحاجة لبروتوكول WebSocket لأن الطرفين كود جافا نكتبه نحن، وليس متصفحاً خارجياً).
 */
public class NetBridge {
    private final Activity activity;
    private final WebView web;
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final AtomicInteger sessionId = new AtomicInteger(0);

    private volatile ServerSocket serverSocket;
    private volatile Socket socket;
    private volatile OutputStream out;

    NetBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    @JavascriptInterface
    public String localIps() {
        StringBuilder sb = new StringBuilder();
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            while (ifaces != null && ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (sb.length() > 0) sb.append(",");
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) { }
        return sb.toString();
    }

    @JavascriptInterface
    public void host(final int port) {
        final int my = sessionId.incrementAndGet();
        closeQuietly();
        io.execute(() -> {
            try {
                ServerSocket ss = new ServerSocket(port);
                serverSocket = ss;
                postStatus("waiting");
                Socket s = ss.accept();
                if (my != sessionId.get()) { s.close(); return; }
                attach(s, my);
            } catch (IOException e) {
                if (my == sessionId.get()) postStatus("error:" + safe(e.getMessage()));
            }
        });
    }

    @JavascriptInterface
    public void join(final String ip, final int port) {
        final int my = sessionId.incrementAndGet();
        closeQuietly();
        io.execute(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, port), 6000);
                if (my != sessionId.get()) { s.close(); return; }
                attach(s, my);
            } catch (IOException e) {
                if (my == sessionId.get()) postStatus("error:" + safe(e.getMessage()));
            }
        });
    }

    private void attach(final Socket s, final int my) {
        try {
            socket = s;
            out = s.getOutputStream();
            postStatus("connected");
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while (my == sessionId.get() && (line = br.readLine()) != null) {
                postMessage(line);
            }
        } catch (IOException ignored) {
        } finally {
            if (my == sessionId.get()) postStatus("disconnected");
        }
    }

    @JavascriptInterface
    public void send(final String msg) {
        final OutputStream o = out;
        if (o == null) return;
        io.execute(() -> {
            try {
                o.write((msg + "\n").getBytes(StandardCharsets.UTF_8));
                o.flush();
            } catch (IOException ignored) { }
        });
    }

    @JavascriptInterface
    public void stop() {
        sessionId.incrementAndGet();
        closeQuietly();
        postStatus("disconnected");
    }

    private void closeQuietly() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) { }
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) { }
        socket = null;
        out = null;
        serverSocket = null;
    }

    private void postStatus(String status) {
        final String js = "window.NetStatus&&window.NetStatus(" + JSONObject.quote(status) + ")";
        activity.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void postMessage(String raw) {
        final String js = "window.NetRecv&&window.NetRecv(" + JSONObject.quote(raw) + ")";
        activity.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private static String safe(String s) { return s == null ? "unknown" : s; }

    void destroy() {
        sessionId.incrementAndGet();
        closeQuietly();
        io.shutdownNow();
    }
}
